import java.util.Scanner;

public class ParImpar {

	public static void main(String[] args) {
	       Scanner scanner = new Scanner(System.in);

	        System.out.print("Ingrese un número: ");
	        int numero = scanner.nextInt();

	        String paroimpar = (numero % 2 == 0) ? "par" : "impar";
	        System.out.println("El número es " + paroimpar);

	}

}
